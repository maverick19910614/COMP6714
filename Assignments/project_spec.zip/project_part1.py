def WAND_Algo(query_terms, top_k, inverted_index):
    pass ## Replace this line with your implementation...!
